// Global Variables
var allTextAreas = $('.textarea')
var saveInput = $('.saveBtn');


window.onload = loadVariable;
function loadVariable() {
  var times=['8:00 AM','9:00 AM','10:00 AM','11:00 AM','12:00 PM','1:00 PM','2:00 PM','3:00 PM','4:00 PM','5:00 PM']
  for (let index = 0; index < 10; index++) {
    let localStorageValue = localStorage.getItem(times[index]);
    console.log(localStorage.getItem(times[index]))
    document.getElementById(index).innerHTML = localStorageValue
  }
}

// Save input to local Storage
saveInput.on('click', function(event){
event.preventDefault()
var text = $(this).siblings('textarea').val()
var time = $(this).siblings('div').text()
console.log(text, time)
localStorage.setItem(time, text);

}) 



//Current Time and Date
var currentTime = function () {
    document.getElementById('currentTime').innerText = moment().format(
      "dddd, MMM Do, h:mm:ss a"
    );
  };
  setInterval(currentTime, 1000);


// Setting the time by color
allTextAreas.each(function(){

var blockHour = parseInt($(this).parent().attr('id').split('-')[1])
console.log(blockHour)
var currentHour = moment().hour()
console.log(currentHour)




  if (currentHour === blockHour) {
  $(this).removeClass('past');
  $(this).removeClass('future');
  $(this).addClass('present');
} else if (currentHour < blockHour) {
  $(this).removeClass('past');
  $(this).removeClass('present');

  $(this).addClass('future');
 
} else {
  $(this).removeClass('future');
  $(this).removeClass('present');

  $(this).addClass('past');
}
}) 
// Not working:
 //var allTextAreas = $('.textarea')


//for (var i = 0; i < currentTime.length; i++) {

 //  if (currentTime > time) {
 //  $(allTextAreas).addClass('future');
 //}else if (currentTime === time) {
 //  $(allTextAreas).addClass('present');
// } else {
//   $(allTextAreas).addClass('past');
// }
// }
